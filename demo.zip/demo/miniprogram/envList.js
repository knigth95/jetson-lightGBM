const envList = [{"envId":"cloud1-4g2y3jkp301b906f","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}